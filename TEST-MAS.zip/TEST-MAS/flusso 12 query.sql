--select * from circuito_condizione
--where identificativo_esercente='40
--where id_job='7f440c7905ae9009f4008cae3ab201fb alichat
--and identificativo_pdv='00001'
select * from log_aggiuntivo where job_id='7f440c7905ae9009f4008cae3ab201fb';
select * from log_contabile where job_id='7f440c7905ae9009f4008cae3ab201fb';
select * from log_dettaglio where job_id='7f440c7905ae9009f4008cae3ab201fb';
