--QUERY VERIFICA VARIAZIONI STATO TERMINALE DA GT (FLUSSO 5)
-- Flusso variazione di stato da GT a MAS
-- Aggiornamento stato di alcuni record su DB MAS
-- cutoff ogni mezzora
--Controllare che la variazione dello stato presente nel flusso sia coerente con lo stato nella tabella TERMINALE-CONVENZIONE
------------------------------------------------------------------------------------

select * from TERMINALE_CONDIZIONE where  job_id = '____';
select * from TERMINALE_CONDIZIONE where  job_id = '____';

--select * from TERMINALE_CONDIZIONE where job_id in ('____','____');
--select * from TERMINALE_CONDIZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------
