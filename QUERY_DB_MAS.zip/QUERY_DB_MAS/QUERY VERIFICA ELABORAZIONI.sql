--QUERY VERIFICA ELABORAZIONI
--tabella ETL_JOB
--		0 --> successo
--		8-9 --> errore con indicazione file
--		
--tabella Flow_import fornisce errore in dettaglio interrogabile sempre con JOB_ID
------------------------------------------------------------------------------------

select * from ETL_JOB where  job_id = '____';
select * from FLOW_IMPORT where  job_id = '____';

--select * from ETL_JOB where job_id in ('____','____');
--select * from FLOW_IMPORT where job_id in ('____','____');