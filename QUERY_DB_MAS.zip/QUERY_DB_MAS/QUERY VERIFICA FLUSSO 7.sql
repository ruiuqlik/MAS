--QUERY VARIAZIONI ANAGRAFICA DA GT (FLUSSO 7)
-- Flusso di Variazioni Anagrafiche da GT
-- Contiene le variazioni anagrafiche da GT da ribaltare su MAS
--Variazioni dei dati aggiuntivi del terminale
-- Stessi controlli flusso 1
-- Stesso tracciato flusso 1 + descrizioni GT a fine record
-- Verificare nelle varie tabelle che i record siano stati aggiornati secondo le variazioni presenti nel flusso

------------------------------------------------------------------------------------

select * from ANAGRAFICA where  job_id = '____';
select * from ANAGRAFICA where  job_id = '____';

--select * from ANAGRAFICA where job_id in ('____','____');
--select * from ANAGRAFICA where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from ESERCENTE where  job_id = '____';
select * from ESERCENTE where  job_id = '____';

--select * from ESERCENTE where job_id in ('____','____');
--select * from ESERCENTE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from PUNTO_VENDITA where  job_id = '____';
select * from PUNTO_VENDITA where  job_id = '____';

--select * from PUNTO_VENDITA where job_id in ('____','____');
--select * from PUNTO_VENDITA where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from CONVENZIONE where  job_id = '____';
select * from CONVENZIONE where  job_id = '____';

--select * from CONVENZIONE where job_id in ('____','____');
--select * from CONVENZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE where  job_id = '____';
select * from TERMINALE where  job_id = '____';

--select * from TERMINALE where job_id in ('____','____');
--select * from TERMINALE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE where  job_id = '____';
select * from TERMINALE where  job_id = '____';

--select * from TERMINALE where job_id in ('____','____');
--select * from TERMINALE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_ACCESSORIO where  job_id = '____';
select * from TERMINALE_ACCESSORIO where  job_id = '____';

--select * from TERMINALE_ACCESSORIO where job_id in ('____','____');
--select * from TERMINALE_ACCESSORIO where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_CONVENZIONE where  job_id = '____';
select * from TERMINALE_CONVENZIONE where  job_id = '____';

--select * from TERMINALE_CONVENZIONE where job_id in ('____','____');
--select * from TERMINALE_CONVENZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_CONVENZIONE_FUNZIONE where  job_id = '____';
select * from TERMINALE_CONVENZIONE_FUNZIONE where  job_id = '____';

--select * from TERMINALE_CONVENZIONE_FUNZIONE where job_id in ('____','____');
--select * from TERMINALE_CONVENZIONE_FUNZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------
