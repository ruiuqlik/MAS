--QUERY VERIFICA CENSIMENTO CONDIZIONI DA BANCA (FLUSSO 15)
-- Flusso proveniente dalla banca per censire le condizioni relative ad ogni merchant.
-- Le condizioni applicate sono composte da un importo fisso e una % sull'importo per transazione
--Controllare presenza campi obbligatori 
--Tabella CIRCUITO_CONDIZIONE (TIPO_RECORD, IDENTIFICATIVO_ABI, IDENTIFICATIVO_NDG, IDENTIFICATIVO_ESERCENTE,
-- IDENTIFICATIVO_PDV, IDENTIFICATIVO_CIRCUITO, TIPOLOGIA_OPERAZIONE, DATA_DECORRENZA_CONDIZIONE, TIPO_AZIONE, TIPOLOGIA_CONDIZIONE, MID)--  
------------------------------------------------------------------------------------

select * from CIRCUITO_CONDIZIONE where  job_id = '____';
select * from CIRCUITO_CONDIZIONE where  job_id = '____';

--select * from CIRCUITO_CONDIZIONE where job_id in ('____','____');
--select * from CIRCUITO_CONDIZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------
