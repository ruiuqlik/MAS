--QUERY VERIFICA CARICAMENTO ANAGRAFICA (FLUSSO 1)
--  TREC 01 Tabella ANAGRAFICA Dati anagrafici dell’esercente ( indirizzo, sede legale, …)
--  TREC 02 Tabella ESERCENTE  Dati specifici collegati all’esercente
--  TREC 03 Tabella PUNTO_VENDITA  Dati specifici del punto vendita Punto vendita
--  TREC 04 Tabella CONVENZIONE  Ogni record identifica un circuiti da abilitare (Alipay, Jiffy,Wechat, …) per il punto vendita
--  TREC 05 Tabella TERMINALE  Identificativi del terminale da abilitare. Sarà presente un record per ogni terminale
--  TREC 06 Tabella TERMINALE_ACCESSORIO  Informazioni relative ad eventuali accessori da associare al terminale (Lettore barcode, Pinpad, Cavo ECR, …)
--  TREC 07 Tabella TRMINALE_CONVENZIONE  Informazioni relative alle convenzioni da abilitare sul terminale (Alipay, Jiffy, WeChat, …)
--  TREC 08 Tabella TRMINALE_CONVENZIONE_FUNZIONE
------------------------------------------------------------------------------------

select * from ANAGRAFICA where  job_id = '____';
select * from ANAGRAFICA where  job_id = '____';

--select * from ANAGRAFICA where job_id in ('____','____');
--select * from ANAGRAFICA where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from ESERCENTE where  job_id = '____';
select * from ESERCENTE where  job_id = '____';

--select * from ESERCENTE where job_id in ('____','____');
--select * from ESERCENTE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from PUNTO_VENDITA where  job_id = '____';
select * from PUNTO_VENDITA where  job_id = '____';

--select * from PUNTO_VENDITA where job_id in ('____','____');
--select * from PUNTO_VENDITA where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from CONVENZIONE where  job_id = '____';
select * from CONVENZIONE where  job_id = '____';

--select * from CONVENZIONE where job_id in ('____','____');
--select * from CONVENZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE where  job_id = '____';
select * from TERMINALE where  job_id = '____';

--select * from TERMINALE where job_id in ('____','____');
--select * from TERMINALE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE where  job_id = '____';
select * from TERMINALE where  job_id = '____';

--select * from TERMINALE where job_id in ('____','____');
--select * from TERMINALE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_ACCESSORIO where  job_id = '____';
select * from TERMINALE_ACCESSORIO where  job_id = '____';

--select * from TERMINALE_ACCESSORIO where job_id in ('____','____');
--select * from TERMINALE_ACCESSORIO where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_CONVENZIONE where  job_id = '____';
select * from TERMINALE_CONVENZIONE where  job_id = '____';

--select * from TERMINALE_CONVENZIONE where job_id in ('____','____');
--select * from TERMINALE_CONVENZIONE where job_id in ('____','____');
------------------------------------------------------------------------------------

select * from TERMINALE_CONVENZIONE_FUNZIONE where  job_id = '____';
select * from TERMINALE_CONVENZIONE_FUNZIONE where  job_id = '____';

--select * from TERMINALE_CONVENZIONE_FUNZIONE where job_id in ('____','____');
--select * from TERMINALE_CONVENZIONE_FUNZIONE where job_id in ('____','____');